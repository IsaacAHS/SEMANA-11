package com.example.lab9_base.Bean;

public class Partido {
    private int idPartido;
    private String fecha;
    private int numeroJornada;
<<<<<<< HEAD
    /*private SeleccionNacional seleccionLocal;
    private SeleccionNacional seleccionVisitante;*/
=======
    private Seleccion seleccionLocal;
    private Seleccion seleccionVisitante;
>>>>>>> 2534a7d7e244ca6ef6eb07574a563a381d109c5c
    private Arbitro arbitro;
    private Estadio estadio;

    public int getIdPartido() {
        return idPartido;
    }

    public void setIdPartido(int idPartido) {
        this.idPartido = idPartido;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getNumeroJornada() {
        return numeroJornada;
    }

    public void setNumeroJornada(int numeroJornada) {
        this.numeroJornada = numeroJornada;
    }

<<<<<<< HEAD
    /*public SeleccionNacional getSeleccionLocal() {
=======
    public Seleccion getSeleccionLocal() {
>>>>>>> 2534a7d7e244ca6ef6eb07574a563a381d109c5c
        return seleccionLocal;
    }

    public void setSeleccionLocal(Seleccion seleccionLocal) {
        this.seleccionLocal = seleccionLocal;
    }

    public Seleccion getSeleccionVisitante() {
        return seleccionVisitante;
    }

    public void setSeleccionVisitante(Seleccion seleccionVisitante) {
        this.seleccionVisitante = seleccionVisitante;
    }*/

    public Arbitro getArbitro() {
        return arbitro;
    }

    public void setArbitro(Arbitro arbitro) {
        this.arbitro = arbitro;
    }

    public Estadio getEstadio() {
        return estadio;
    }

    public void setEstadio(Estadio estadio) {
        this.estadio = estadio;
    }
}
