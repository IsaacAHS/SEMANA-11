package com.example.lab9_base.Controller;

import com.example.lab9_base.Bean.Arbitro;
import com.example.lab9_base.Dao.DaoArbitros;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet(name = "ArbitroServlet", urlPatterns = {"/ArbitroServlet"})
public class ArbitroServlet extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");

        String action = request.getParameter("action") == null ? "lista" : request.getParameter("action");

        DaoArbitros daoArbitros = new DaoArbitros();

        switch (action){
            case "lista":
                //saca del modelo
                ArrayList<Arbitro> list = daoArbitros.listarArbitros();

                //mandar la lista a la vista -> job/lista.jsp
                request.setAttribute("lista",list);
                RequestDispatcher rd = request.getRequestDispatcher("arbitros/list.jsp");
                rd.forward(request,response);
                break;
            case "new":
                request.getRequestDispatcher("employee/employee_new.jsp").forward(request,response);
                break;
            case "del":
                String idd = request.getParameter("id");
                int idd2 = Integer.parseInt(idd);

                Arbitro arbitro = DaoArbitros.buscarArbitro(idd2);

                /*if(arbitro != null){
                    try {
                        daoArbitros.borrarArbitro(idd2);
                    } catch (SQLException e) {
                        System.out.println("Log: excepcion: " + e.getMessage());
                    }
                }*/
                response.sendRedirect(request.getContextPath() + "/ArbitroServlet");
                break;
                /*ahora*/
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action") == null ? "lista" : request.getParameter("action");
        RequestDispatcher view;
        ArrayList<String> opciones = new ArrayList<>();
        opciones.add("nombre");
        opciones.add("pais");

        switch (action) {

            case "buscar":
                /*
                Inserte su código aquí
                */
                break;

            case "guardar":
                /*
                Inserte su código aquí
                */
                break;

        }
    }


}
